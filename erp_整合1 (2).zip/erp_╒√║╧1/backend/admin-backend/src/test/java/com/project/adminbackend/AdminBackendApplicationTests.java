package com.project.adminbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
