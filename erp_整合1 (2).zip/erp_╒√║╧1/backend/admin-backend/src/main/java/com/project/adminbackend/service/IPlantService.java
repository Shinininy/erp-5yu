package com.project.adminbackend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.project.adminbackend.pojo.Plant;

public interface IPlantService extends IService<Plant> {
}
