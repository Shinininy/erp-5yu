package com.project.adminbackend.pojo.request;

import lombok.Data;

/**
 * 封装了  /operates/salesOrder/query 这个接口的请求参数对象
 */
@Data
public class IdQueryParam {
    private Integer id;
}
