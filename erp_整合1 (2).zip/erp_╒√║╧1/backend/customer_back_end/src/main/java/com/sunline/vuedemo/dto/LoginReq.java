package com.sunline.vuedemo.dto;

import lombok.Data;

@Data
public class LoginReq {
    private String userName;
    private String passWord;
}
