package com.sunline.vuedemo.service;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sunline.vuedemo.bean.ContactpersonEntity;

import java.util.Map;

/**
 * 
 *
 * @author Zero
 * @email Zero@gmail.com
 * @date 2023-07-14 21:54:53
 */
public interface ContactpersonService extends IService<ContactpersonEntity> {

   // PageUtils queryPage(Map<String, Object> params);
}

