package com.example.sdorder.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.sdorder.configuration.BaseDao;
import com.example.sdorder.entity.Details;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface DetailsMapper extends BaseDao<Details> {

}
