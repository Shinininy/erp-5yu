package com.example.sdorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SdorderApplicationTests {

    @Test
    void contextLoads() {
    }

}
