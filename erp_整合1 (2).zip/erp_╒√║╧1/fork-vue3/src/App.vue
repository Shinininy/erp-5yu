<template>
  <router-view />
</template>

<script>
export default {
  name: 'app'
}
</script>
<style>
.app-container {
  padding: 10px
}

html,
body,
#app {
  height: 100%;
  width: 100%;
}

* {
  padding: 0;
  margin: 0;
}
</style>
